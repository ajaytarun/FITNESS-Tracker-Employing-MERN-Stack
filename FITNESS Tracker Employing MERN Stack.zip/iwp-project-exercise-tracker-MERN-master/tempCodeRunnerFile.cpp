#include <climits>
#include <stdio.h>
#include <conio.h>
#include <bits/stdc++.h>
#include <iostream>
#include <vector>
#include <string>
#include <math.h>
using namespace std;
int main()
{
    int ma;
    cin>>ma;
    cout<<ma;
    return 0;
}